// background/background.js

console.log("AI Job Assistant Background Worker initialized.");

let isRunning = false;

// Load initial state
chrome.storage.local.get(['botRunning'], (data) => {
    isRunning = !!data.botRunning;
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'TOGGLE_BOT') {
        isRunning = request.state;
        console.log(`Bot state changed to: ${isRunning}`);
        sendLogToPopup(`Bot ${isRunning ? 'started' : 'stopped'}.`);
        sendResponse({ success: true });
        return true;
    }
    
    if (request.type === 'FORWARD_LOG') {
        sendLogToPopup(`[Bot] ${request.message}`);
        sendResponse({ success: true });
        return true;
    }

    if (request.type === 'EVALUATE_JOB') {
        if (!isRunning) {
            sendResponse({ success: false, reason: 'Bot is paused' });
            return true;
        }

        const jobData = request.data;
        console.log("Received job for evaluation:", jobData.title);
        
        // Evaluate asynchronously
        evaluateJobWithLLM(jobData).then(result => {
            sendResponse(result);
        }).catch(err => {
            console.error("Evaluation error:", err);
            sendResponse({ success: false, error: err.toString() });
        });
        
        return true; // Keeps the sendResponse channel open for async
    }
});

async function evaluateJobWithLLM(jobData) {
    sendLogToPopup(`Evaluating: ${jobData.title}`);
    
    // Get stored data
    const storage = await chrome.storage.local.get(['apiKey', 'resumeSummary', 'sheetUrl']);
    if (!storage.apiKey) {
        sendLogToPopup("ERROR: No API Key found.");
        throw new Error("Missing API Key");
    }

    // LLM Prompt configuration
    const systemPrompt = `You are a career assistant. I am applying for jobs. Evaluate this job description based on my resume summary.
Format your response as a JSON object: {"is_match": true|false, "reasoning": "brief explanation"}`;

    const userMessage = `My Resume/Skills: ${storage.resumeSummary || 'Not provided'}
Job Title: ${jobData.title}
Job Company: ${jobData.company}
Job Description:
${jobData.description}`;

    try {
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${storage.apiKey}`
            },
            body: JSON.stringify({
                model: 'gpt-4o-mini', // Using mini for cost/speed
                messages: [
                    { role: 'system', content: systemPrompt },
                    { role: 'user', content: userMessage }
                ],
                response_format: { type: "json_object" },
                temperature: 0.3
            })
        });

        if (!response.ok) throw new Error(`OpenAI API error: ${response.status}`);
        
        const jsonResponse = await response.json();
        const content = JSON.parse(jsonResponse.choices[0].message.content);
        
        sendLogToPopup(`Match: ${content.is_match} - ${content.reasoning}`);
        
        // Extract ID from URL if provided
        if (content.is_match && storage.sheetUrl) {
            sendLogToPopup("Saving to Google Sheets...");
            
            // Extract the actual Google Sheet ID from the full URL using regex
            const match = storage.sheetUrl.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
            if (match && match[1]) {
                await appendToGoogleSheets(jobData, content, match[1]);
            } else {
                sendLogToPopup("ERROR: Invalid Google Sheet URL format.");
            }
        }
        
        return { success: true, evaluation: content };
    } catch (e) {
        sendLogToPopup(`Failed LLM eval: ${e.message}`);
        console.error(e);
        return { success: false, error: e.message };
    }
}

async function appendToGoogleSheets(jobData, evaluation, sheetId) {
    return new Promise((resolve, reject) => {
        chrome.identity.getAuthToken({ interactive: true }, async function(token) {
            if (chrome.runtime.lastError || !token) {
                sendLogToPopup("Google OAuth Error: " + chrome.runtime.lastError.message);
                return resolve(false);
            }

            const range = "Sheet1!A:F"; // Adjust based on your sheet
            const valueInputOption = "USER_ENTERED";
            
            // Format: [Date, Details, Role, URL, Status, Reasoning]
            const values = [[
                new Date().toISOString(),
                `${jobData.title} at ${jobData.company}`,
                "Matched Role", // Would dynamically come from profile match in production
                jobData.url,
                "Draft",
                evaluation.reasoning
            ]];

            const url = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${range}:append?valueInputOption=${valueInputOption}`;
            
            try {
                const res = await fetch(url, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ values })
                });

                if (!res.ok) throw new Error("Sheets API returned " + res.status);
                sendLogToPopup("✅ Saved to Google Sheets!");
                resolve(true);
            } catch (err) {
                sendLogToPopup("Failed saving to Sheets: " + err.message);
                resolve(false);
            }
        });
    });
}

function sendLogToPopup(message) {
    const time = new Date().toLocaleTimeString([], { hour12: false });
    const fullLog = `[${time}] ${message}`;

    // Save to storage so it persists when popup reopens
    chrome.storage.local.get(['sessionLogs'], (data) => {
        let logs = data.sessionLogs || [];
        logs.unshift(fullLog); // pre-pend
        if (logs.length > 50) logs.pop(); // keep only last 50 logs
        chrome.storage.local.set({ sessionLogs: logs });
    });

    // Send to popup if it happens to be open
    chrome.runtime.sendMessage({ type: 'LOG_MESSAGE', message: fullLog }).catch(() => {
        // Ignore errors if popup is closed
    });
}
